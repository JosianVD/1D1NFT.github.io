"use client";

export { MediaRenderer } from "@thirdweb-dev/react";
